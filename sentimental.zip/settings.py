import nltk

nltk.download()